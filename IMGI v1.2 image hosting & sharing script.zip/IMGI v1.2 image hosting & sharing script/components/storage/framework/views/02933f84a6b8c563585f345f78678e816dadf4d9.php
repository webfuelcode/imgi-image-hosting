<!-- Edit term modal -->
<div class="modal fade" id="edit<?php echo e($faq->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Edit</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('updatefaq', $faq->id)); ?>" method="POST" role="form">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="modal-body">
              <div class="form-group">
                  <label><span class="text-danger">*</span> Question</label>
                  <input type="text" class="form-control" name="question" value="<?php echo e($faq->question); ?>">
              </div>
              <div class="form-group">
                  <label for="answer"><span class="text-danger">*</span> Answer</label> (HTML allowed)
                  <textarea class="form-control" style="height:150px" name="answer"><?php echo e($faq->answer); ?></textarea>
              </div>
          </div>

          <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/modal/faq_edit.blade.php ENDPATH**/ ?>