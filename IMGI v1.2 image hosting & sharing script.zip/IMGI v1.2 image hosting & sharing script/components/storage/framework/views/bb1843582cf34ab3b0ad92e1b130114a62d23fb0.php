<!-- Delete Image modal -->
<div class="modal fade" id="delete<?php echo e($img->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">You are going to delete an image</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          Are you sure to delete this image: <strong><?php echo e($img->description ?? '_Description N/A_'); ?></strong>?
        </div>
        <div class="modal-footer">
            <form action="<?php echo e(route('imgdelete', $img->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-danger">Yes, delete</button>
            </form>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xamppi\htdocs\imgi\resources\views/admin/modal/img_del.blade.php ENDPATH**/ ?>