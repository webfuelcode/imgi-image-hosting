

<?php $__env->startSection('title', 'Terms'); ?>
<?php $__env->startSection('pagetitle', 'Manage term page'); ?>
<?php $__env->startSection('page', 'Terms'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Terms of service</h4>
            <p>
                Write or edit your terms for using the site. You can add basic <strong>HTML code</strong> to render your text.
            </p>
            <form action="<?php echo e(route('updateterm')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>            
            
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <textarea class="form-control" style="height:450px" name="terms"><?php echo e($term->terms); ?></textarea>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            
            </form>
        </div>
    </div>

<div class="card bg-warning">
    <div class="card-body text-info">
        <h4 class="card-header mb-4">Term view page</h4>
            <?php echo $term->terms; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\imgi\resources\views/admin/term.blade.php ENDPATH**/ ?>