

<?php $__env->startSection('title', 'Admin dashboard'); ?>
<?php $__env->startSection('pagetitle', 'Admin area'); ?>
<?php $__env->startSection('page', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body pb-0">
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-6">
                        <div class="card card-hover">
                            <div class="box bg-cyan text-center">
                                <h1 class="font-light text-white"><i class="mdi mdi-account-multiple"></i></h1>
                                <h6 class="text-white"><?php echo e($user->count()); ?></h6>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <div class="col-md-6">
                        <div class="card card-hover">
                            <div class="box bg-success text-center">
                                <h1 class="font-light text-white"><i class="mdi mdi-folder-multiple-image"></i></h1>
                                <h6 class="text-white"><?php echo e($imgcount); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <h2>Recently uploaded images</h2>
    <div class="card">
        <div class="card-body">
            <div class="row el-element-overlay">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-6">
                        <div class="card">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" class="imgsize"/>
                                    <div class="el-overlay">
                                        <ul class="list-style-none el-info">
                                            <li class="el-item"><a class="btn default btn-outline image-popup-vertical-fit el-link" href="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>"><i class="mdi mdi-magnify-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <h4 class="m-b-0"><?php echo e($img->description); ?></h4>
                                    <span>
                                        <a class="btn btn-danger btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#delete<?php echo e($img->id); ?>">Delete</a>
                                        <?php echo $__env->make('admin.modal.img_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <a class="btn btn-success btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#path<?php echo e($img->id); ?>">Path</a>
                                        <?php echo $__env->make('admin.modal.img_path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>