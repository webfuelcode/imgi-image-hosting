<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Image Hosting')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/imgi-assets/favicon.png')); ?>" type="image">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    
    <!-- jQuery used for flash notice -->
    <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/admin/css/icons/font-awesome/css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/imgi.css')); ?>" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
	
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
              <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'IMGI')); ?></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
          
              <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                  <li class="nav-item">
                    <a href="<?php echo e(route('gallery')); ?>" class="nav-link <?php echo e(Request::is('page/gallery') ? 'active' : ''); ?>">Gallery</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('contact')); ?>" class="nav-link <?php echo e(Request::is('page/contact') ? 'active' : ''); ?>">Contact</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('faq')); ?>" class="nav-link <?php echo e(Request::is('page/faq') ? 'active' : ''); ?>">FAQ</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('terms')); ?>" class="nav-link <?php echo e(Request::is('page/terms-of-service') ? 'active' : ''); ?>">Terms of Services</a>
                </li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary"><i class="fas fa-bolt"></i> Admin area</a>
                        
                            
                        <?php endif; ?>
                    <?php endif; ?>
                
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"> <?php echo e(__('Login')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <i class="fas fa-user-circle"></i> <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i class="fas fa-address-card"></i> Dashboard</a>

                                <a class="dropdown-item" href="<?php echo e(route('userprofile', Auth::user()->id)); ?>"><i class="fas fa-user"></i> Profile</a>

                                <a class="dropdown-item" href="<?php echo e(route('useredit', Auth::user()->id)); ?>"><i class="fas fa-wrench"></i> User edit</a>

                                
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <i class="fas fa-lock"></i> <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
                
              </div>
            </div>
          </nav>

        <main class="container">
            <div class="my-4">
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <div class="container my-3">
            <small>
                &copy; imgi.wall-spot.com - All Rights  Reserved.<br>
                Powered By <u>IMGI Image Hosting</u> Script | Developed By <a href="http://webfuelcode.wall-spot.com" target="_blank" rel="noopener noreferrer">webfuelcode</a>
            </small>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xamppi\htdocs\imgi\resources\views/layouts/app.blade.php ENDPATH**/ ?>