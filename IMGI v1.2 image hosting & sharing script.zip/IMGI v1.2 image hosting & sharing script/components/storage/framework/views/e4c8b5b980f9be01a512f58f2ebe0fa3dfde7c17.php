

<?php $__env->startSection('title', 'FAQs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card my-3">
        <div class="card-header">
            Frequestly asked questions
        </div>
        <div class="card-body">
            <h2>Frequently Asked Questions</h2>

					<?php $__empty_1 = true; $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="card my-3 bg-secondary">
							<div class="card-header"><?php echo e($faq->question); ?></div>
							<div class="card-body"><?php echo $faq->answer; ?></div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<p class="text-warning">
							__There are no FAQs available.__
						</p>
					<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/pages/faq.blade.php ENDPATH**/ ?>