<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card border-dark my-3">
        <div class="card-header">Image Host</div>
        <div class="card-body">
            <p>
                Upload your images/photos to our free image hosting service and share them with your friends, family and colleagues.
            </p>
            <p>
                <strong>Supported Image Formats:</strong> png, jpg, jpeg, gif, bmp<br>
                <strong>Maximum Filesizes:</strong> 2 MB
            </p>
            <p class="mb-3 text-center">
                <?php echo $ads->note; ?>

            </p>

            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card bg-dark">
                        <div class="card-body">
                        
                            <!-- Image upload form starts -->
                            <form class="form-vertical" action="<?php echo e(route('create')); ?>" method="POST" role="form" id="create-thread-form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Description</label>
                                        <input type="text" class="form-control" name="description" placeholder="description">
                                    </div>
                                    <div class="form-group">
                                        <label for="image"><span class="text-danger">*</span> Image</label>
                                        <input class="form-control" type="file" name="image">
                                    </div>
                                </div>
                    
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
                                </div>
                            </form>
                            <!-- Image upload form ends -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <p class="mb-3 text-center">
        <?php echo $ads->ads; ?>

    </p>

    <div class="card">
        <div class="card-body">
            Please note that uploading adult content is not allowed! Any such content will be deleted. Check our <a href="<?php echo e(route('terms')); ?>">Terms of Services</a> for upload rules.
        </div>
    </div>

    <div class="card my-3">
        <div class="card-header">
            Random Images
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-6 col-lg-2">
                        <a href="<?php echo e(route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))])); ?>">
                            <img src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" alt="<?php echo e($img->description); ?>" class="img-fluid imgsize my-2">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/welcome.blade.php ENDPATH**/ ?>