

<?php $__env->startSection('title', 'Image gallery'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card my-3">
        <div class="card-body text-center">
            <?php echo $ads->ads; ?>

        </div>
    </div>

    <div class="card my-3">
        <div class="card-header">
            Images
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-3 col-lg-2 mb-4">
                        <div class="card h-100  bg-secondary">
                            <div class="card-body">
                                <div class="m-0">
                                    <a href="<?php echo e(route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))])); ?>">
                                        <img class="rounded img-fluid imgsize" src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" alt="<?php echo e($img->description); ?>">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-link mt-4">
                <?php echo e($images->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\imgi\resources\views/pages/gallery.blade.php ENDPATH**/ ?>