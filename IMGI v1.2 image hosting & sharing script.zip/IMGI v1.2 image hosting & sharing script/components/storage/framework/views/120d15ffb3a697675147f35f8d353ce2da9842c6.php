

<?php $__env->startSection('title', 'Support'); ?>
<?php $__env->startSection('pagetitle', 'Support'); ?>
<?php $__env->startSection('page', 'Support'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Welcome</h4>
            <p>Thanks a lot for your interest here.</p>
            <p>Image sharing & hosting script <strong>imgi hosting</strong> script is free to use and we need your support to continue this script.</p>
            <p>If you find it interesting, please support by any of the following methods. You can also support by purchasing products throught the links (affiliate).</p>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Donation</h4>
            <p>You can send some dollars through PayPal. <a href="https://www.paypal.com/paypalme/webfuelcode" class="btn btn-sm btn-success"><i class="far fa-money-bill-alt"></i> Send</a></p>
            <p>Also, crypto wallets are available.</p>
            <p>
                <strong>Bitcoin (BTC)</strong> – 1AtRVevmRpxDdjcYKQt8chUxjFm1Pgkcfh<br>
                <strong>Bitcoin Cash (BCH)</strong> – qrtz7qs6nqkkn5rsflf7rkeyx8xlnrkzwuxl3z7pg9<br>
                <strong>Litecoin (LTC)</strong> – LXmCZpURPEtsTg4oSCCtgRfmuopPnp6VQr<br>
                <strong>Dogecoin (DOGE)</strong> – DBRXP7jCosw4huoDqDfHWf9QGETcebsqCH<br>
                <strong>Ethereum (ETH)</strong> – 0xfDd5fef075038eEC513c263Bc7036b655E1A96ef
            </p>
        </div>
    </div>
            
    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Web hosting</h4>
            <p>For best web server we have classified some of reliable hosting services that you may like to try.</p>
            <p><a href="http://www.wall-spot.com/web-hosting-starters" target="_blank"><img src="<?php echo e(asset('img/imgi-assets/hosting.png')); ?>" class="img-fluid"></a></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/donate.blade.php ENDPATH**/ ?>