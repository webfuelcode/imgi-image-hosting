

<?php $__env->startSection('title', 'Images'); ?>
<?php $__env->startSection('pagetitle', 'Image list'); ?>
<?php $__env->startSection('page', 'Images'); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">
                Manage images (<?php echo e($images->count()); ?>)
            </h4>
            <div class="row el-element-overlay">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="card bg-light">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" />
                                    <div class="el-overlay">
                                        <ul class="list-style-none el-info">
                                            <li class="el-item"><a class="btn default btn-outline image-popup-vertical-fit el-link" href="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>"><i class="mdi mdi-magnify-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <span>
                                        <a class="btn btn-danger btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#delete<?php echo e($img->id); ?>">Delete</a>
                                        <?php echo $__env->make('admin.modal.img_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <a class="btn btn-success btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#path<?php echo e($img->id); ?>">Path</a>
                                        <?php echo $__env->make('admin.modal.img_path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($images->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/images.blade.php ENDPATH**/ ?>