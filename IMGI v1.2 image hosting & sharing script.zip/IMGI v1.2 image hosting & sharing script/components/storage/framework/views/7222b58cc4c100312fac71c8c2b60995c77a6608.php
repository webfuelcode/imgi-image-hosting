

<?php $__env->startSection('title', 'Profile page'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row my-3">
            <!-- Column -->
            <div class="col-md-6">
                <div class="card card-hover">
                    <div class="box bg-info text-center">
                        <h1 class="font-light text-white"><i class="mdi mdi-view-dashboard"></i></h1>
                        <h6 class="text-white"><?php echo e(__('Profile of')); ?> <?php echo e($user->name); ?>!</h6>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6">
                <div class="card card-hover">
                    <div class="box bg-success text-center">
                        <h1 class="font-light text-white"><i class="mdi mdi-chart-areaspline"></i></h1>
                        <h6 class="text-white">Total <?php echo e($images->count()); ?> <?php echo e(__('Images')); ?></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="m-0">
                                <a href="<?php echo e(route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))])); ?>">
                                    <img class="rounded img-fluid" src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" alt="<?php echo e($img->description); ?>">
                                </a>
                            </div>
                            <div class="my-2"><?php echo e($img->description); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card">
                        <div class="card-body">
                            <p><?php echo e($user->name); ?> has no image to show here.</p>
                        </div>
                    </div>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/users/profile.blade.php ENDPATH**/ ?>