

<?php $__env->startSection('title', 'Site Settings'); ?>
<?php $__env->startSection('pagetitle', 'Manage site settings'); ?>
<?php $__env->startSection('page', 'Site Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        Welocme to site settings page. Here you can manage your welcome <strong>display note, adsense ad script</strong> and the site bottom <strong>copyright note</strong>.
    </div>
</div>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('updatesettings', $setting->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Site note: <small class="text-muted">(Your note for homepage HTML allowed)</small></label>
                            <textarea class="form-control" style="height:100px" name="note"><?php echo e($setting->note); ?></textarea>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            
            
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('updatesettings', $setting->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Ad code: <small class="text-muted">(Adsense program script or HTML code)</small></label>
                            <textarea class="form-control" style="height:100px" name="ads"><?php echo e($setting->ads); ?></textarea>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('updatesettings', $setting->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Copyright note: <small class="text-muted">(Footer copyright text)</small></label>
                            
                            <input type="text" class="form-control" name="copyright" value="<?php echo e($setting->copyright); ?>">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\imgi\resources\views/admin/settings.blade.php ENDPATH**/ ?>