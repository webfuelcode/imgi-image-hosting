

<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('pagetitle', 'Manage contact page'); ?>
<?php $__env->startSection('page', 'Contact'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Contact message</h4>
            <p>
                Write or edit your how the visitors and business messages you will handle. You can add basic <strong>HTML code</strong> to render your text.
            </p>
            <form action="<?php echo e(route('updatecontact')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>            
            
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <textarea class="form-control" style="height:450px" name="message"><?php echo e($contact->message); ?></textarea>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            
            </form>
        </div>
    </div>

<div class="card bg-warning">
    <div class="card-body text-info">
        <h4 class="card-header mb-4">Contact view page</h4>
            <?php echo $contact->message; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/contact.blade.php ENDPATH**/ ?>