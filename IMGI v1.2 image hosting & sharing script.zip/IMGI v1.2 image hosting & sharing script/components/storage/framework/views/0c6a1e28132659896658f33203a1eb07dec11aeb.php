<?php $__env->startSection('title', 'Welcome home'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center my-2">
        <div class="col-8">
            
                    <div class="row">
                        <!-- Column -->
                        <div class="col-md-6">
                            <div class="card card-hover">
                                <div class="box bg-info text-center">
                                    <h1 class="font-light text-white"><i class="mdi mdi-view-dashboard"></i></h1>
                                    <h6 class="text-white"><?php echo e(__('Welcome')); ?> <?php echo e($user->name); ?>!</h6>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <div class="col-md-6">
                            <div class="card card-hover">
                                <div class="box bg-success text-center">
                                    <h1 class="font-light text-white"><i class="mdi mdi-chart-areaspline"></i></h1>
                                    <h6 class="text-white">Total <?php echo e($imgcount); ?> <?php echo e(__('Images')); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                
        </div>
    </div>

    <div class="row justify-content-center mb-4">
        <div class="col-md-8">
            <div class="card bg-secondary">
                <div class="card-header"><?php echo e(__('Images')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $userimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-3 mb-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="m-0">
                                        <a href="<?php echo e(route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))])); ?>">
                                            <img class="rounded img-fluid" src="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" alt="<?php echo e($img->description); ?>">
                                        </a>
                                    </div>
                                </div>

                                <span class="card-footer text-center">
                                    <form action="<?php echo e(route('imgdelete', $img->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Sure</button>
                                    </form>
                                </span>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-warning"><em>There are no images in your account.</em></p>
                            <p class="d-flex justify-content-center"><a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-upload"></i> Upload</a></p>
                        <?php endif; ?>
                    </div>

                    <div class="text-link mt-4">
                        <?php echo e($userimages->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/home.blade.php ENDPATH**/ ?>