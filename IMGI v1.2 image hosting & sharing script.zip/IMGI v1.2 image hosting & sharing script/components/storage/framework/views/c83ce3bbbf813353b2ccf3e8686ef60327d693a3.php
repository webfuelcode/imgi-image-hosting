

<?php $__env->startSection('title', 'Contact page'); ?>

<?php $__env->startSection('content'); ?>


    <div class="card my-3">
        <div class="card-header">
            Contact
        </div>
        <div class="card-body">
                <?php echo $contact->message; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\imgi\resources\views/pages/contact.blade.php ENDPATH**/ ?>