<!-- Image path modal -->
<div class="modal fade" id="path<?php echo e($img->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Image path</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" value="<?php echo e(asset('img/images')); ?>/<?php echo e($img->image); ?>" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    
                </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/modal/img_path.blade.php ENDPATH**/ ?>