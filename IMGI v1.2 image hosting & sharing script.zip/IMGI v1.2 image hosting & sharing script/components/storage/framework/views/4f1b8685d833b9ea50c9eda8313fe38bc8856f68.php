

<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('pagetitle', 'User management'); ?>
<?php $__env->startSection('page', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">
                Users
            </h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Name</th>
                                <th scope="col">Images</th>
                                <th scope="col">Email</th>
                                <th scope="col">Joined</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody class="customtable">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td>
                                    <?php echo e($user->name); ?>

                                    <?php if($user->role == 'admin'): ?>
                                        <i class="fas fa-bolt text-success"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->images->count()); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                <td>
                                    <?php if($user->role == 'admin' || $user->id == 2): ?>
                                        <a href="<?php echo e(route('userprofile', $user->id)); ?>" target="_blank" class="btn btn-primary btn-sm">View</a>
                                        <span class="badge badge-pill badge-secondary">N/A</span>
                                    <?php else: ?>
                                        <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($user->id); ?>"><i class="mdi mdi-delete-empty"></i> Delete</a>
                                        <?php echo $__env->make('admin.modal.user_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </table>

                    <?php echo e($users->links()); ?>

                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/users.blade.php ENDPATH**/ ?>