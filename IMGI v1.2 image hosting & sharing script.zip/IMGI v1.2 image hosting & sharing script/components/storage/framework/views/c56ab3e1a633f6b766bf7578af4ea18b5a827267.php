

<?php $__env->startSection('title', 'FAQs'); ?>
<?php $__env->startSection('pagetitle', 'Frequently asked questions'); ?>
<?php $__env->startSection('page', 'FAQs'); ?>
    
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            
                    <div class="col-12">
                        <h5 class="card-title m-b-0 d-flex no-block align-items-center">
                            <span>FAQs</span>
                            <div class="ml-auto text-right">
                                <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#faq"><i class="mdi mdi-plus-circle-outline"></i> Add new question</a>
                            </div>
                        </h5>
                    </div>
                    <?php echo $__env->make('admin.modal.faq_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
        <table class="table">
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="font-medium"><i class="fas fa-question-circle text-info"></i> <?php echo e($faq->question); ?></div>
                            <div class="text-m"><i class="fas fa-arrow-alt-circle-right text-info"></i> <?php echo e($faq->answer); ?></div>
                        </td>
                        <td>
                            <a href="#" title="Edit" data-toggle="modal" data-target="#edit<?php echo e($faq->id); ?>">
                                <i class="fas fa-edit text-warning"></i>
                            </a>
                            <?php echo $__env->make('admin.modal.faq_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        <td>
                            <a href="#" title="Delete" data-toggle="modal" data-target="#delete<?php echo e($faq->id); ?>">
                                <i class="fas fa-times text-danger"></i>
                            </a>
                            <?php echo $__env->make('admin.modal.faq_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-warning">
                    __There are no frequently asked questions you have created yet.__
                </p>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/admin/faq.blade.php ENDPATH**/ ?>