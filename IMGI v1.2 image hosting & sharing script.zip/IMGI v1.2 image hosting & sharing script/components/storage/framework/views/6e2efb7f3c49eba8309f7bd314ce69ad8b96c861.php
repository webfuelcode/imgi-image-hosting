

<?php $__env->startSection('title', 'Image details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card my-3">
        <div class="card-header">
            Image
        </div>
        <div class="card-body">
            <div class="text-center">
                <img class="img-fluid" src="<?php echo e(asset('img/images')); ?>/<?php echo e($image->image); ?>" alt="">
                <p><?php echo e($image->description); ?></p></div>
        </div>
    </div>

    <div class="card my-3">
      <div class="card-body text-center">
          <?php echo $ads->ads; ?>

      </div>
    </div>

    <div class="card">
        <div class="card-header">
            Image links
        </div>
        <div class="card-body">
            <h4>Page link</h4>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">BBcode (Forums)</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value="[URL=<?php echo e(route('show', [$image->id, preg_replace('/\+/', '-', urlencode($image->description))])); ?>][IMG]<?php echo e(asset('img/images')); ?>/<?php echo e($image->image); ?>[/IMG][/URL]">
                </div>

                <label for="" class="col-sm-2 col-form-label">HTML Code</label>
                <div class="col-sm-10">
                  <input type='text' readonly='' class='form-control' id='staticEmail' value='<a href="<?php echo e(route('show', [$image->id, preg_replace('/\+/', '-', urlencode($image->description))])); ?>" title="<?php echo e($image->description); ?>" ><img src="<?php echo e(asset('img')); ?>/images/<?php echo e($image->image); ?>" alt="<?php echo e($image->description); ?>" /></a>'>
                </div>
            </div>

            <h4>Image link</h4>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">BBcode (Forums)</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value="[IMG]<?php echo e(asset('img/images')); ?>/<?php echo e($image->image); ?>[/IMG]">
                </div>

                <label for="" class="col-sm-2 col-form-label">HTML Code</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value='<img src="<?php echo e(asset('img/images')); ?>/<?php echo e($image->image); ?>">'>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imgi\resources\views/pages/single.blade.php ENDPATH**/ ?>