<?php

namespace App\Http\Controllers;

use App\Models\Image;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class ImageController extends Controller
{

    public function random()
    {
        $images = Image::inRandomOrder()->limit(6)->get();
        return view('welcome', compact('images'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request, Image $image)
    {
        $validated = $this->validate($request,[            
            'description'=>'sometimes',
            'image'=>'required|image|mimes:jpeg,jpg,png,gif,bmp|max:2048'
        ]);

            $filename = time() . '.' . $request->image->getClientOriginalExtension();
            $request->image->storeAs('images', $filename, 'public');
            
            $validated['image'] = $filename;

        //store
        if (Auth::check()) {
            $validated['user_id'] = Auth::id();
        } else {
            $validated['user_id'] = 2;
        }
    
        $image = Image::create($validated);

        return redirect()->route('show', compact('image'))->withMessage('Your image file has uploaded successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Image  $image
     * @return \Illuminate\Http\Response
     */
    public function show(Image $image)
    {
        $ads = Setting::first();
        return view('pages.single', compact('image', 'ads'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Image  $image
     * @return \Illuminate\Http\Response
     */
    public function destroy(Image $image)
    {
        Storage::disk('public')->delete('images/' . $image->image);
        $image->delete();
        return redirect()->back()->withMessage('The image has deleted successfully!');
    }
}