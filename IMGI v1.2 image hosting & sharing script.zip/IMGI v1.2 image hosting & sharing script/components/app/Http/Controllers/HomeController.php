<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();
        $imgcount = $user->images()->count();
        $userimages = Image::where('user_id', Auth::user()->id)->latest()->paginate(20);
        return view('home', compact('user', 'imgcount', 'userimages'));
    }

    public function dashboard()
    {
        $user = User::all();
        $images = Image::latest()->take(6)->get();
        $imgcount = Image::count();
        return view('admin.dashboard', compact('user', 'images', 'imgcount'));
    }

    public function donate()
    {
        return view('admin.donate');
    }

    public function imglist()
    {
        $images = Image::latest()->paginate(24);
        return view('admin.images', compact('images'));
    }
}
