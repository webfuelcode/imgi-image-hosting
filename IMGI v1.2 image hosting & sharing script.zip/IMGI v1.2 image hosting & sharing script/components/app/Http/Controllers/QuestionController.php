<?php

namespace App\Http\Controllers;

use App\Models\Question;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $question = Question::all();
        return view('admin.faq', compact('question'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $validated = $this->validate($request,[
            'name'=>'required|min:4',
            'description'=>'required|min:20',
            'visible'=>'accepted'
        ]);

        $page = Page::create($validated);
        return redirect()->route('adpages')->withMessage('A new page has been created!');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $this->validate($request,[
            'question' => 'required',
            'answer' => 'required'
        ]);
        $faq = Question::create($validated);
        
        //redirect
        return redirect()->back()->withMessage('New question has been added successfully!');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Question  $question
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Question $question)
    {
        $validated = $this->validate($request,[
            'question'=>'required|min:4',
            'answer'=>'required|min:10'
        ]);

        $question->update($validated);
        return redirect()->back()->withMessage('Question has been updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Question  $question
     * @return \Illuminate\Http\Response
     */
    public function destroy(Question $question)
    {
        $question->delete();
        return redirect()->back()->withMessage('Question has been deleted successfully!');
    }
}
