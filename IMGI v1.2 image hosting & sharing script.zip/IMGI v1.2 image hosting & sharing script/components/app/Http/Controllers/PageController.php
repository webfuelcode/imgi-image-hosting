<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use App\Models\Term;
use App\Models\Setting;
use App\Models\Contact;
use App\Models\Question;

class PageController extends Controller
{
    public function contact()
    {
        $contact = Contact::first();
        return view('pages.contact', compact('contact'));
    }

    public function faq()
    {
        $question = Question::all();
        return view('pages.faq', compact('question'));
    }

    public function terms()
    {
        $term = Term::first();
        return view('pages.terms', compact('term'));
    }

    public function gallery()
    {
        $ads = Setting::first();
        $images = Image::latest()->paginate(42);
        return view('pages.gallery', compact('images', 'ads'));
    }
}
