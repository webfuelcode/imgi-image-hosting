<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Image;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use App\Rules\MatchOldPassword;

class UserController extends Controller
{
    public function index()
    {
        $users = User::orderBy('name')->paginate(10);
        return view('admin.users', compact('users'))->with('i', (request()->input('page', 1) -1) * 10);
    }

    public function useredit()
    {
        $user = Auth::user();
        return view('users.edit', compact('user'));
    }

    public function profile(User $user)
    {
        $images = Image::where('user_id', $user->id)->latest()->get(); /** User uploaded images with no page links on profile page */
        return view('users.profile', compact('user', 'images'));
    }

    // User update
    public function update(Request $request, User $user)
    {
        $this->validate(request(), [
            'email' => ['sometimes', Rule::unique('users')->ignore($user->id),],
            //'password' => 'sometimes|min:6|same:confirm password',            
        ]);
        
        $user->name = request('name');
        $user->email = request('email');

    // Avatar update
    if($request->hasFile('profile_image')){
        $filename = time() . '.' . $request->profile_image->getClientOriginalExtension();
        if(auth()->user()->profile_image){
            Storage::disk('public')->delete('avatar/' . auth()->user()->profile_image);
        }
        $request->profile_image->storeAs('avatar', $filename, 'public');
        
        $user = Auth::user();
        $user->profile_image = $filename;
    }

        $user->save();
        return redirect()->back()->withMessage('Your personal data has successfully updated!');
    }

    /**
     * Password update and matching logic.
     */
    public function updatepass(Request $request)
    {
        $request->validate([
            'current_password' => ['required', new MatchOldPassword],
            'new_password' => ['required'],
            'new_confirm_password' => ['same:new_password'],
        ]);
   
        User::find(auth()->user()->id)->update(['password'=> Hash::make($request->new_password)]);
   
        return redirect()->back()->withMessage('Password is changed successfully!');
    }

    /**
     * Delete user
     */
    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->back()->withMessage('User has been deleted successfully from the database!');
    }
}
