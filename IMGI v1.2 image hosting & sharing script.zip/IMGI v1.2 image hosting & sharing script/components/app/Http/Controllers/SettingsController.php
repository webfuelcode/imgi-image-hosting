<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Setting;

class SettingsController extends Controller
{
    //** Setting page view */
    public function settings()
    {
        $setting = Setting::first();
        return view('admin.settings', compact('setting'));
    }

    //** Note update */
    public function updatesettings(Request $request, Setting $setting)
    {
        $validated = $this->validate($request,[
            'note'=>'sometimes',
            'ads'=>'sometimes',
            'copyright'=>'sometimes'
        ]);

        // $setting = Setting::first();
        $setting->update($validated);
        return redirect()->back()->withMessage('Site settings has been update successfully!');
    }
}
