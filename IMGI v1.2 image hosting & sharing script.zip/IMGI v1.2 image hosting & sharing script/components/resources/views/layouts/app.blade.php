<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Image Hosting') }} | @yield('title')</title>
    <link rel="shortcut icon" href="{{asset('img/imgi-assets/favicon.png')}}" type="image">

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
    
    <!-- jQuery used for flash notice -->
    <script src="{{asset('assets/admin/js/jquery.min.js')}}"></script>
    <link href="{{asset('assets/admin/css/icons/font-awesome/css/fontawesome-all.min.css')}}" rel="stylesheet">
    <link href="{{asset('css/imgi.css')}}" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
	
    @yield('head')
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
              <a class="navbar-brand" href="{{url('/')}}">{{ config('app.name', 'IMGI') }}</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
          
              <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                  <li class="nav-item">
                    <a href="{{ route('gallery') }}" class="nav-link {{Request::is('page/gallery') ? 'active' : ''}}">Gallery</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('contact') }}" class="nav-link {{Request::is('page/contact') ? 'active' : ''}}">Contact</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('faq') }}" class="nav-link {{Request::is('page/faq') ? 'active' : ''}}">FAQ</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('terms') }}" class="nav-link {{Request::is('page/terms-of-service') ? 'active' : ''}}">Terms of Services</a>
                </li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto">
                    @auth
                        @if (Auth::user()->role == 'admin')
                            <a href="{{route('dashboard')}}" class="btn btn-secondary"><i class="fas fa-bolt"></i> Admin area</a>
                        {{-- @else --}}
                            
                        @endif
                    @endauth
                
                    <!-- Authentication Links -->
                    @guest
                        @if (Route::has('login'))
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}"> {{ __('Login') }}</a>
                            </li>
                        @endif

                        @if (Route::has('register'))
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                            </li>
                        @endif
                    @else
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <i class="fas fa-user-circle"></i> {{ Auth::user()->name }}
                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('home') }}"><i class="fas fa-address-card"></i> Dashboard</a>

                                <a class="dropdown-item" href="{{route('userprofile', Auth::user()->id)}}"><i class="fas fa-user"></i> Profile</a>

                                <a class="dropdown-item" href="{{route('useredit', Auth::user()->id)}}"><i class="fas fa-wrench"></i> User edit</a>

                                
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <i class="fas fa-lock"></i> {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </div>
                        </li>
                    @endguest
                </ul>
                {{-- <form class="d-flex">
                  <input class="form-control me-sm-2" type="text" placeholder="Search">
                  <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
                </form> --}}
              </div>
            </div>
          </nav>

        <main class="container">
            <div class="my-4">
                @include('layouts.msg')
            </div>
            
            @yield('content')
        </main>
        <div class="container my-3">
            <small>
                &copy; imgi.wall-spot.com - All Rights  Reserved.<br>
                Powered By <u>IMGI Image Hosting</u> Script | Developed By <a href="http://webfuelcode.wall-spot.com" target="_blank" rel="noopener noreferrer">webfuelcode</a>
            </small>
        </div>
    </div>
</body>
</html>
