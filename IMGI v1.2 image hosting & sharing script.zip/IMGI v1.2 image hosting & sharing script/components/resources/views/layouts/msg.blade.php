@if (session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>        
@endif

<script>
    window.setTimeout(function() {
    $(".alert-success").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 5000);
</script>

@if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>                    
            @endforeach
        </ul>
    </div>        
@endif