@extends('layouts.app')

@section('title', 'Welcome')

@section('content')
    <div class="card border-dark my-3">
        <div class="card-header">Image Host</div>
        <div class="card-body">
            <p>
                Upload your images/photos to our free image hosting service and share them with your friends, family and colleagues.
            </p>
            <p>
                <strong>Supported Image Formats:</strong> png, jpg, jpeg, gif, bmp<br>
                <strong>Maximum Filesizes:</strong> 2 MB
            </p>
            <p class="mb-3 text-center">
                {!!$ads->note!!}
            </p>

            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card bg-dark">
                        <div class="card-body">
                        
                            <!-- Image upload form starts -->
                            <form class="form-vertical" action="{{ route('create') }}" method="POST" role="form" id="create-thread-form" enctype="multipart/form-data">
                                @csrf
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Description</label>
                                        <input type="text" class="form-control" name="description" placeholder="description">
                                    </div>
                                    <div class="form-group">
                                        <label for="image"><span class="text-danger">*</span> Image</label>
                                        <input class="form-control" type="file" name="image">
                                    </div>
                                </div>
                    
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
                                </div>
                            </form>
                            <!-- Image upload form ends -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <p class="mb-3 text-center">
        {!!$ads->ads!!}
    </p>

    <div class="card">
        <div class="card-body">
            Please note that uploading adult content is not allowed! Any such content will be deleted. Check our <a href="{{route('terms')}}">Terms of Services</a> for upload rules.
        </div>
    </div>

    <div class="card my-3">
        <div class="card-header">
            Random Images
        </div>
        <div class="card-body">
            <div class="row">
                @foreach ($images as $img)
                    <div class="col-sm-12 col-md-6 col-lg-2">
                        <a href="{{ route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))]) }}">
                            <img src="{{asset('img/images')}}/{{$img->image}}" alt="{{$img->description}}" class="img-fluid imgsize my-2">
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection