@extends('layouts.app')

@section('title', 'Terms of Services')

@section('content')
    <div class="card my-3">
        <div class="card-header">
            Terms of Services
        </div>
        <div class="card-body">
            {!!$term->terms!!}
        </div>
    </div>
@endsection