@extends('layouts.app')

@section('title', 'FAQs')

@section('content')
    <div class="card my-3">
        <div class="card-header">
            Frequestly asked questions
        </div>
        <div class="card-body">
            <h2>Frequently Asked Questions</h2>

					@forelse ($question as $faq)
						<div class="card my-3 bg-secondary">
							<div class="card-header">{{$faq->question}}</div>
							<div class="card-body">{!!$faq->answer!!}</div>
						</div>
					@empty
						<p class="text-warning">
							__There are no FAQs available.__
						</p>
					@endforelse
        </div>
    </div>
@endsection