@extends('layouts.app')

@section('title', 'Image gallery')

@section('content')
    <div class="card my-3">
        <div class="card-body text-center">
            {!!$ads->ads!!}
        </div>
    </div>

    <div class="card my-3">
        <div class="card-header">
            Images
        </div>
        <div class="card-body">
            <div class="row">
                @foreach ($images as $img)
                    <div class="col-sm-6 col-md-3 col-lg-2 mb-4">
                        <div class="card h-100  bg-secondary">
                            <div class="card-body">
                                <div class="m-0">
                                    <a href="{{ route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))]) }}">
                                        <img class="rounded img-fluid imgsize" src="{{asset('img/images')}}/{{$img->image}}" alt="{{$img->description}}">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="card-link mt-4">
                {{$images->links()}}
            </div>
        </div>
    </div>
@endsection