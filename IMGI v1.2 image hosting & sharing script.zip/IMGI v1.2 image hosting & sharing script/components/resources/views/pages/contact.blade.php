@extends('layouts.app')

@section('title', 'Contact page')

@section('content')
{{-- <div class="card my-3">
    <div class="card-body text-center">
        {!!$ads->ads!!}
    </div>
</div> --}}

    <div class="card my-3">
        <div class="card-header">
            Contact
        </div>
        <div class="card-body">
                {!!$contact->message!!}
        </div>
    </div>
@endsection