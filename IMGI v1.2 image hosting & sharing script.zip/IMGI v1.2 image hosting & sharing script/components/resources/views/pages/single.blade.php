@extends('layouts.app')

@section('title', 'Image details')

@section('content')
    <div class="card my-3">
        <div class="card-header">
            Image
        </div>
        <div class="card-body">
            <div class="text-center">
                <img class="img-fluid" src="{{asset('img/images')}}/{{$image->image}}" alt="">
                <p>{{$image->description}}</p>
            </div>
        </div>
    </div>

    <div class="card my-3">
      <div class="card-body text-center">
          {!!$ads->ads!!}
      </div>
    </div>

    <div class="card">
        <div class="card-header">
            Image links
        </div>
        <div class="card-body">
            <h4>Page link</h4>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">BBcode (Forums)</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value="[URL={{ route('show', [$image->id, preg_replace('/\+/', '-', urlencode($image->description))]) }}][IMG]{{asset('img/images')}}/{{$image->image}}[/IMG][/URL]">
                </div>

                <label for="" class="col-sm-2 col-form-label">HTML Code</label>
                <div class="col-sm-10">
                  <input type='text' readonly='' class='form-control' id='staticEmail' value='<a href="{{ route('show', [$image->id, preg_replace('/\+/', '-', urlencode($image->description))]) }}" title="{{$image->description}}" ><img src="{{asset('img')}}/images/{{$image->image}}" alt="{{$image->description}}" /></a>'>
                </div>
            </div>

            <h4>Image link</h4>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">BBcode (Forums)</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value="[IMG]{{asset('img/images')}}/{{$image->image}}[/IMG]">
                </div>

                <label for="" class="col-sm-2 col-form-label">HTML Code</label>
                <div class="col-sm-10">
                  <input type="text" readonly="" class="form-control" id="staticEmail" value='<img src="{{asset('img/images')}}/{{$image->image}}">'>
                </div>
            </div>
        </div>
    </div>
@endsection