@extends('layouts.app')

@section('title', 'Welcome home')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark">
                <div class="card-body">
                
                    <!-- Image upload form starts -->
                    <form class="form-vertical" action="{{ route('create') }}" method="POST" role="form" id="create-thread-form" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body row">
                            <div class="form-group col-md-6">
                                <label>Description</label>
                                <input type="text" class="form-control" name="description" placeholder="Within 225 char...">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="image"><span class="text-danger">*</span> Image (Max. 2MB)</label>
                                <input class="form-control" type="file" name="image">
                            </div>
                        </div>
            
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-upload"></i> Upload</button>
                        </div>
                    </form>
                    <!-- Image upload form ends -->
                </div>
            </div>
        </div>
    </div><!-- Image upload box ends here -->

    <div class="row justify-content-center my-2">
        <div class="col-8">
            {{-- <div class="">
                <div class="">
                    <h5 class="">Icon Box</h5>| --}}
                    <div class="row">
                        <!-- Column -->
                        <div class="col-md-6">
                            <div class="card card-hover">
                                <div class="box bg-info text-center">
                                    <h1 class="font-light text-white"><i class="mdi mdi-view-dashboard"></i></h1>
                                    <h6 class="text-white">{{__('Welcome')}} {{$user->name}}!</h6>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <div class="col-md-6">
                            <div class="card card-hover">
                                <div class="box bg-success text-center">
                                    <h1 class="font-light text-white"><i class="mdi mdi-chart-areaspline"></i></h1>
                                    <h6 class="text-white">Total {{$imgcount}} {{__('Images')}}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                {{-- </div>
            </div> --}}
        </div>
    </div>

    <div class="row justify-content-center mb-4">
        <div class="col-md-8">
            <div class="card bg-secondary">
                <div class="card-header">{{ __('Images') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif


                    <div class="row">
                        @forelse ($userimages as $img)
                        <div class="col-md-3 mb-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="m-0">
                                        <a href="{{ route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))]) }}">
                                            <img class="rounded img-fluid" src="{{asset('img/images')}}/{{$img->image}}" alt="{{$img->description}}">
                                        </a>
                                    </div>
                                </div>

                                <span class="card-footer text-center">
                                    <form action="{{ route('imgdelete', $img->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Sure</button>
                                    </form>
                                </span>
                            </div>
                        </div>

                        @empty
                            <p class="text-warning"><em>There are no images in your account.</em></p>
                            <p class="d-flex justify-content-center"><a href="{{url('/')}}" class="btn btn-secondary btn-sm"><i class="fas fa-upload"></i> Upload</a></p>
                        @endforelse
                    </div>

                    <div class="text-link mt-4">
                        {{$userimages->links()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
