<!-- Edit term modal -->
<div class="modal fade" id="edit{{$faq->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Edit</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="{{ route('updatefaq', $faq->id) }}" method="POST" role="form">
          @csrf
          @method('PUT')
          <div class="modal-body">
              <div class="form-group">
                  <label><span class="text-danger">*</span> Question</label>
                  <input type="text" class="form-control" name="question" value="{{$faq->question}}">
              </div>
              <div class="form-group">
                  <label for="answer"><span class="text-danger">*</span> Answer</label> (HTML allowed)
                  <textarea class="form-control" style="height:150px" name="answer">{{$faq->answer}}</textarea>
              </div>
          </div>

          <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>