<!-- Edit term modal -->
<div class="modal fade" id="edit{{$term->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Edit</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="{{ route('termupdate', $term->slug) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Brand name:</label>
                        <input type="text" name="name" value="{{ old('name', $term->name) }}" class="form-control">
                    </div>

                    <div class="form-group">
                      <label for="image"><span class="text-danger">*</span> Image</label> <em>(Use 200x170 px for better view)</em>
                      <input type="file" name="image" id="">
                    </div>

                    <div class="alert alert-warning">
                      NOTE: Updating a brand will not generate a new slug value. It is assumed that you won't like to mess up the site SEO.
                    </div>
                </div>
                <div class="modal-footer">
                    
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Update</button>
                    
                </div>
        </form>
      </div>
    </div>
  </div>