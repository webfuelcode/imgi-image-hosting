@extends('admin.app')

@section('title', 'Users')
@section('pagetitle', 'User management')
@section('page', 'Users')

@section('content')
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">
                Users
            </h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Name</th>
                                <th scope="col">Images</th>
                                <th scope="col">Email</th>
                                <th scope="col">Joined</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody class="customtable">
                            @foreach ($users as $user)
                            <tr>
                                <td>{{++$i}}</td>
                                <td>
                                    {{$user->name}}
                                    @if ($user->role == 'admin')
                                        <i class="fas fa-bolt text-success"></i>
                                    @endif
                                </td>
                                <td>{{$user->images->count()}}</td>
                                <td>{{$user->email}}</td>
                                <td>{{$user->created_at->diffForHumans()}}</td>
                                <td>
                                    @if ($user->role == 'admin' || $user->id == 2)
                                        <a href="{{route('userprofile', $user->id)}}" target="_blank" class="btn btn-primary btn-sm">View</a>
                                        <span class="badge badge-pill badge-secondary">N/A</span>
                                    @else
                                        <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete{{$user->id}}"><i class="mdi mdi-delete-empty"></i> Delete</a>
                                        @include('admin.modal.user_del')
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </td>
                    </table>

                    {{$users->links()}}
                </div>
        </div>
    </div>
@endsection