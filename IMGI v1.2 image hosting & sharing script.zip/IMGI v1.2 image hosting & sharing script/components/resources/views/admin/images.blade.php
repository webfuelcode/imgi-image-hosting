@extends('admin.app')

@section('title', 'Images')
@section('pagetitle', 'Image list')
@section('page', 'Images')

@section('content')    
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">
                Manage images ({{$images->count()}})
            </h4>
            <div class="row el-element-overlay">
                @foreach ($images as $img)
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="card bg-light">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="{{asset('img/images')}}/{{$img->image}}" />
                                    <div class="el-overlay">
                                        <ul class="list-style-none el-info">
                                            <li class="el-item"><a class="btn default btn-outline image-popup-vertical-fit el-link" href="{{asset('img/images')}}/{{$img->image}}"><i class="mdi mdi-magnify-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <span>
                                        <a class="btn btn-danger btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#delete{{$img->id}}">Delete</a>
                                        @include('admin.modal.img_del')
                                        <a class="btn btn-success btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#path{{$img->id}}">Path</a>
                                        @include('admin.modal.img_path')
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            {{$images->links()}}
        </div>
    </div>
@endsection