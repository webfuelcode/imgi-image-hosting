@extends('admin.app')

@section('title', 'Terms')
@section('pagetitle', 'Manage term page')
@section('page', 'Terms')

@section('content')

    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Terms of service</h4>
            <p>
                Write or edit your terms for using the site. You can add basic <strong>HTML code</strong> to render your text.
            </p>
            <form action="{{ route('updateterm') }}" method="POST">
                @csrf
                @method('PUT')            
            
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <textarea class="form-control" style="height:450px" name="terms">{{$term->terms}}</textarea>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            
            </form>
        </div>
    </div>

<div class="card bg-warning">
    <div class="card-body text-info">
        <h4 class="card-header mb-4">Term view page</h4>
            {!!$term->terms!!}
    </div>
</div>
@endsection