@extends('admin.app')

@section('title', 'FAQs')
@section('pagetitle', 'Frequently asked questions')
@section('page', 'FAQs')
    
@section('content')

    <div class="card">
        <div class="card-body">
            
                    <div class="col-12">
                        <h5 class="card-title m-b-0 d-flex no-block align-items-center">
                            <span>FAQs</span>
                            <div class="ml-auto text-right">
                                <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#faq"><i class="mdi mdi-plus-circle-outline"></i> Add new question</a>
                            </div>
                        </h5>
                    </div>
                    @include('admin.modal.faq_create')
            
        </div>
        <table class="table">
            <tbody>
                @forelse ($question as $faq)
                    <tr>
                        <td>
                            <div class="font-medium"><i class="fas fa-question-circle text-info"></i> {{$faq->question}}</div>
                            <div class="text-m"><i class="fas fa-arrow-alt-circle-right text-info"></i> {{$faq->answer}}</div>
                        </td>
                        <td>
                            <a href="#" title="Edit" data-toggle="modal" data-target="#edit{{$faq->id}}">
                                <i class="fas fa-edit text-warning"></i>
                            </a>
                            @include('admin.modal.faq_edit')
                        </td>
                        <td>
                            <a href="#" title="Delete" data-toggle="modal" data-target="#delete{{$faq->id}}">
                                <i class="fas fa-times text-danger"></i>
                            </a>
                            @include('admin.modal.faq_del')
                        </td>
                    </tr>
                @empty
                <p class="text-warning">
                    __There are no frequently asked questions you have created yet.__
                </p>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection