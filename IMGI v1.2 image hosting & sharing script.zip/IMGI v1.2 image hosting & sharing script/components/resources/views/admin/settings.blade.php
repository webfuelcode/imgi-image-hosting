@extends('admin.app')

@section('title', 'Site Settings')
@section('pagetitle', 'Manage site settings')
@section('page', 'Site Settings')

@section('content')
<div class="card">
    <div class="card-body">
        Welocme to site settings page. Here you can manage your welcome <strong>display note, adsense ad script</strong> and the site bottom <strong>copyright note</strong>.
    </div>
</div>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('updatesettings', $setting->id) }}" method="POST">
                @csrf
                @method('PUT')
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Site note: <small class="text-muted">(Your note for homepage HTML allowed)</small></label>
                            <textarea class="form-control" style="height:100px" name="note">{{$setting->note}}</textarea>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            
            
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('updatesettings', $setting->id) }}" method="POST">
                @csrf
                @method('PUT')
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Ad code: <small class="text-muted">(Adsense program script or HTML code)</small></label>
                            <textarea class="form-control" style="height:100px" name="ads">{{$setting->ads}}</textarea>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('updatesettings', $setting->id) }}" method="POST">
                @csrf
                @method('PUT')
            
            
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label>Copyright note: <small class="text-muted">(Footer copyright text)</small></label>
                            {{-- <textarea class="form-control" style="height:100px" name="terms">{{$setting->copyright}}</textarea> --}}
                            <input type="text" class="form-control" name="copyright" value="{{$setting->copyright}}">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection