@extends('admin.app')

@section('title', 'Admin dashboard')
@section('pagetitle', 'Admin area')
@section('page', 'Dashboard')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body pb-0">
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-6">
                        <div class="card card-hover">
                            <div class="box bg-cyan text-center">
                                <h1 class="font-light text-white"><i class="mdi mdi-account-multiple"></i></h1>
                                <h6 class="text-white">{{$user->count()}}</h6>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <div class="col-md-6">
                        <div class="card card-hover">
                            <div class="box bg-success text-center">
                                <h1 class="font-light text-white"><i class="mdi mdi-folder-multiple-image"></i></h1>
                                <h6 class="text-white">{{$imgcount}}</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <h2>Recently uploaded images</h2>
    <div class="card">
        <div class="card-body">
            <div class="row el-element-overlay">
                @foreach ($images as $img)
                    <div class="col-lg-2 col-md-6">
                        <div class="card">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="{{asset('img/images')}}/{{$img->image}}" class=""/>
                                    <div class="el-overlay">
                                        <ul class="list-style-none el-info">
                                            <li class="el-item"><a class="btn default btn-outline image-popup-vertical-fit el-link" href="{{asset('img/images')}}/{{$img->image}}"><i class="mdi mdi-magnify-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <h4 class="m-b-0">{{$img->description}}</h4>
                                    <span>
                                        <a class="btn btn-danger btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#delete{{$img->id}}">Delete</a>
                                        @include('admin.modal.img_del')
                                        <a class="btn btn-success btn-sm" href="#" class="dropdown-item" data-toggle="modal" data-target="#path{{$img->id}}">Path</a>
                                        @include('admin.modal.img_path')
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection