@extends('admin.app')

@section('title', 'Support')
@section('pagetitle', 'Support')
@section('page', 'Support')

@section('content')
    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Welcome</h4>
            <p>Thanks a lot for your interest here.</p>
            <p><strong>IMGI Hosting & Sharing Script</strong> is free to use and we need your support to continue this script.</p>
            <p>If you find it interesting, please support by any of the following methods. You can also support by purchasing products throught the links (affiliate).</p>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body">
                    <h4 class="card-title m-b-0">Distributed</h4>
                    <p>Power your web experience with free scripts and generate awesome revenue.</p>
                </div>
                <div class="card-footer">
                    <a href="https://webfuelcode.wall-spot.com" class="btn btn-dark btn-sm" target="_blank">See more</a>
                </div>
            </div>
        </div>
    
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body">
                    <h4 class="card-title m-b-0">Affordable plans</h4>
                    <p>With amazing hosting experience at low cost which also provide offers and free domain name.</p>
                </div>
                <div class="card-footer">
                    <a href="http://gopickhost.com/recommends/hostinger" class="btn btn-dark btn-sm" target="_blank">Premium hosting</a>
                </div>
            </div>
        </div>
    
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body">
                    <h4 class="card-title m-b-0">Thanks a lot</h4>
                    <p>Lots of love and thanks to all.</p>
                </div>
                <div class="card-footer">
                    <a href="https://zazzle.com/store/onesel/products" class="btn btn-dark btn-sm" target="_blank">Custom shirts</a>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Donation</h4>
            <p>You can send some dollars through PayPal. <a href="https://www.paypal.com/paypalme/webfuelcode" class="btn btn-sm btn-success"><i class="far fa-money-bill-alt"></i> Send</a></p>
            <p>Also, crypto wallets are available.</p>
            <p>
                <strong>Bitcoin (BTC)</strong> – 1AtRVevmRpxDdjcYKQt8chUxjFm1Pgkcfh<br>
                <strong>Bitcoin Cash (BCH)</strong> – qrtz7qs6nqkkn5rsflf7rkeyx8xlnrkzwuxl3z7pg9<br>
                <strong>Litecoin (LTC)</strong> – LXmCZpURPEtsTg4oSCCtgRfmuopPnp6VQr<br>
                <strong>Dogecoin (DOGE)</strong> – DBRXP7jCosw4huoDqDfHWf9QGETcebsqCH<br>
                <strong>Ethereum (ETH)</strong> – 0xfDd5fef075038eEC513c263Bc7036b655E1A96ef
            </p>
        </div>
    </div>
            
    <div class="card">
        <div class="card-body">
            <h4 class="card-title m-b-0">Web hosting</h4>
            <p>For best web server we have classified some of reliable hosting services that you may like to try.</p>
            <p><a href="http://www.wall-spot.com/web-hosting-starters" target="_blank"><img src="{{asset('img/imgi-assets/hosting.png')}}" class="img-fluid"></a></p>
        </div>
    </div>

@endsection