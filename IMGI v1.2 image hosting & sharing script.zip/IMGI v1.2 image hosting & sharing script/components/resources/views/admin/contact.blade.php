@extends('admin.app')

@section('title', 'Contact')
@section('pagetitle', 'Manage contact page')
@section('page', 'Contact')

@section('content')

    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Contact message</h4>
            <p>
                Write or edit your how the visitors and business messages you will handle. You can add basic <strong>HTML code</strong> to render your text.
            </p>
            <form action="{{ route('updatecontact') }}" method="POST">
                @csrf
                @method('PUT')            
            
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <textarea class="form-control" style="height:450px" name="message">{{$contact->message}}</textarea>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            
            </form>
        </div>
    </div>

<div class="card bg-warning">
    <div class="card-body text-info">
        <h4 class="card-header mb-4">Contact view page</h4>
            {!!$contact->message!!}
    </div>
</div>
@endsection