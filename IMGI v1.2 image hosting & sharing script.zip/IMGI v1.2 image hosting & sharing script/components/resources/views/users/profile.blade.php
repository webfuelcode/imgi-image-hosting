@extends('layouts.app')

@section('title', 'Profile page')

@section('content')
        <div class="row my-3">
            <!-- Column -->
            <div class="col-md-6">
                <div class="card card-hover">
                    <div class="box bg-info text-center">
                        <h1 class="font-light text-white"><i class="mdi mdi-view-dashboard"></i></h1>
                        <h6 class="text-white">{{__('Profile of')}} {{$user->name}}!</h6>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6">
                <div class="card card-hover">
                    <div class="box bg-success text-center">
                        <h1 class="font-light text-white"><i class="mdi mdi-chart-areaspline"></i></h1>
                        <h6 class="text-white">Total {{$images->count()}} {{__('Images')}}</h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            @forelse ($images as $img)
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="m-0">
                                <a href="{{ route('show', [$img->id, preg_replace('/\+/', '-', urlencode($img->description))]) }}">
                                    <img class="rounded img-fluid" src="{{asset('img/images')}}/{{$img->image}}" alt="{{$img->description}}">
                                </a>
                            </div>
                            <div class="my-2">{{$img->description}}</div>
                        </div>
                    </div>
                </div>
                @empty
                    <div class="card">
                        <div class="card-body">
                            <p>{{$user->name}} has no image to show here.</p>
                        </div>
                    </div>
            @endforelse
        </div>
@endsection