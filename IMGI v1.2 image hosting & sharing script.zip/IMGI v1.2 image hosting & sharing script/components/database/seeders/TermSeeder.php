<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\models\Term;

class TermSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = Term::create([
            'terms' => '<p>
            <h2>Terms of Service</h2>
                            <ul>
                                <li>imgi.wall-spot.com reserves the right to disable or delete any file which might compromise the security of our servers, uses excessive bandwidth, violates this Terms of Service or is otherwise considered undesirable (at our sole discretion).</li>
                                <li>The image hosting service is provided as-is with no implied warranties of any kind. We can not be held responsible for the loss of data or other damages which may result from (lack of) functionality of our service.</li>
                                <li>imgi.wall-spot.com does not allow the following types of files to be uploaded:						<ul>
                                        <li>Images which violate copyrights or patents are not allowed.</li>
                                        <li>Images which contain adult content such as pornography or excessive nudity.</li>
                                        <li>Images which contain gruesome scenes, such as dead people or mutilations.</li>
                                        <li>Images which violate the privacy of the individuals depicted are not allowed.</li>
                                        <li>Images which are considered illegal in your country.</li>
                                    </ul>
                                </li>
                                <li>Files will not be deleted unless they have not been accessed for some time or violate our Terms of Service.</li>
                                <li>imgi.wall-spot.com reserves the right to deny access to any user who uploads files that compromise the security of our servers, use excessive bandwidth or are otherwise deemed to be misusing the free file hosting service.</li>
                                <li>imgi.wall-spot.com reserves the right to modify these Terms of Service at any time without prior notification.</li>
                            </ul>
                            <br/><br/>
                            <h2>Privacy Policy</h2>
                            <ul>
                                <li>We will never sell, rent, or lease our customer information to third parties.</li>
                            </ul>
                        </div>
            </p>'
        ]);
    }
}
