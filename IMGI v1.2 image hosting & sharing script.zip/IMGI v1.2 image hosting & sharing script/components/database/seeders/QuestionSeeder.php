<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\models\Question;

class QuestionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faq = Question::insert([

            [
                'id' => '1',
                'question' => 'What is imgi.wall-spot.com? How do I use it?',
                'answer' => 'We are a free image hosting solution. What is designed for you to share your digital pictures with friends and family, email, post images on forums, social networking sites, blogs and Online auctions sites.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '2',
                'question' => 'How much does the service cost?',
                'answer' => 'This website will always be 100&#37; free! imgi.wall-spot.com is supported by our featured advertisers.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '3',
                'question' => 'Which image file formats are accepted?',
                'answer' => 'PNG, JPG, JPEG, GIF, BMP images and photos can be uploaded using our service.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '4',
                'question' => 'What kinds of pictures will you host for me?',
                'answer' => 'Our service will host any legal image, except for adult-rated images. Any files against the law will be deleted and your info will be reported to the appropriate authorities.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '5',
                'question' => 'I am not able to upload images, why?',
                'answer' => 'Main reason could be the file size and the format.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '6',
                'question' => 'Is direct linking allowed?',
                'answer' => 'Yes, we allow "direct linking" (also referred to as "hot linking"). It&apos;s best to hotlink to the thumbnails leading to the large images to save on bandwidth as there is a limit of  1 GB of bandwidth per Image/month.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '7',
                'question' => 'How long will you store my images?',
                'answer' => 'Barring any unforeseen event, the uploaded images that do not violate our <a href="http://yoursite.com/page/terms-of-services" target="_blank" title="Terms of Service">Terms of Service</a> are stored on our server for forever.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '8',
                'question' => 'What is the max filesize limit?',
                'answer' => 'The maximum file-size is 2 MB.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '9',
                'question' => 'What can I do to help?',
                'answer' => 'Link to us from your web page or profile, and let other people know about our site!',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => '10',
                'question' => 'Have more questions?',
                'answer' => 'Please use the <a href="http://yoursite.com/page/contact" target="_blank" title="Contact page">Contact page</a> to e-mail us.',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]

        ]);
    }
}
