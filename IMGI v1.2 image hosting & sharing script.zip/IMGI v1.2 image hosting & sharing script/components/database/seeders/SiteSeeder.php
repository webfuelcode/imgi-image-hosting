<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\models\Setting;
use App\models\Contact;

class SiteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = Setting::create([
            'ads' => '<a href="http://www.wall-spot.com/web-hosting-starters" target="_blank"><img class="img-fluid" src="../img/imgi-assets/webhosting.png"></a>',
        	'copyright' => 'imgi.wall-spot.com',
        	'note' => 'Welcome to imgi image sharing and hosting site.'
        ]);

        $contact = Contact::create([
            'message' => '<h4>Contact for business</h4>
                            <p>Thanks for your interest. For any kind of business and advertising contact, you are welcome to message using the email below.</p>
                            <p><strong>Email:</strong> advertising@website.com</p>
                            <p><strong>Facebook:</strong> https://www.facebook.com/webfuelcode</p>
                            
                            <h4 class="my-4">Feedback</h4>
                            <p>Follow us on social media and add your feedback and suggestiong.</p>
                            <a class="mx-2" href="#" target="_blank"><i class="fab fa-facebook fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-twitter-square fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-linkedin fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-pinterest fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-instagram fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-whatsapp fa-2x"></i></a> <a class="mx-2" href="#" target="_blank"><i class="fab fa-blogger fa-2x"></i></a>'
        ]);
    }
}
