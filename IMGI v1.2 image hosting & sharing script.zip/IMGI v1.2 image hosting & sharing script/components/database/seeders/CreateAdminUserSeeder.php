<?php

namespace Database\Seeders;
  
use Illuminate\Database\Seeder;
use App\models\User;
use Carbon\Carbon;
  
class CreateAdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::insert([
        	[
                'id' => '1',
                'name' => 'John',
                'role' => 'admin',
        	    'email' => 'admin@gmail.com',
        	    'password' => bcrypt('12345678'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'id' => '2',
                'name' => 'anonymouse',
                'role' => 'NULL',
        	    'email' => 'admin1@gmail.com',
        	    'password' => bcrypt('12345678'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
  
    }
}