<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImageController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\TermController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Models\Image;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/', [Controller::class, 'welcome']);

Route::post('image/upload', [ImageController::class, 'create'])->name('create');
Route::get('image/{image}', [ImageController::class, 'show'])->name('show');
Route::delete('image/{image}', [ImageController::class, 'destroy'])->name('imgdelete');

/**
 * User
 */
Route::get('user/{user}/profile', [UserController::class, 'profile'])->name('userprofile');
Route::get('user/{user}', [UserController::class, 'useredit'])->name('useredit');
Route::put('user/{user}/update', [UserController::class, 'update'])->name('userupdate');
Route::put('user/{user}/pass', [UserController::class, 'updatepass'])->name('userupdatepass');

/**
 * Pages
 */
Route::get('page/contact', [PageController::class, 'contact'])->name('contact');
Route::get('page/faq', [PageController::class, 'faq'])->name('faq');
Route::get('page/terms-of-service', [PageController::class, 'terms'])->name('terms');
Route::get('page/gallery', [PageController::class, 'gallery'])->name('gallery');

/**
 * Admin
 */
Route::get('admin/dashboard', [HomeController::class, 'dashboard'])->name('dashboard');
Route::get('admin/support', [HomeController::class, 'donate'])->name('donate');
Route::get('admin/images', [HomeController::class, 'imglist'])->name('adminimg');
Route::get('admin/term', [TermController::class, 'index'])->name('term');
Route::get('admin/contact', [ContactController::class, 'index'])->name('admincontact');
Route::get('admin/faq', [QuestionController::class, 'index'])->name('adminfaq');
Route::get('admin/users', [UserController::class, 'index'])->name('adminusers');
Route::get('admin/site-settings', [SettingsController::class, 'settings'])->name('settings');

Route::put('admin/term/update', [TermController::class, 'update'])->name('updateterm');
Route::put('admin/contact/update', [ContactController::class, 'update'])->name('updatecontact');
Route::post('admin/faq/new', [QuestionController::class, 'store'])->name('newfaq');
Route::put('admin/faq/{question}/update', [QuestionController::class, 'update'])->name('updatefaq');
Route::delete('admin/faq/{question}/delete', [QuestionController::class, 'destroy'])->name('faqdestroy');
Route::delete('admin/user/{user}/delete', [UserController::class, 'destroy'])->name('userdestroy');
Route::put('admin/site-settings/{setting}/update', [SettingsController::class, 'updatesettings'])->name('updatesettings');